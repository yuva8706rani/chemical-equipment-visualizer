import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [summary, setSummary] = useState(null);
  const [file, setFile] = useState(null);

  const fetchSummary = async () => {
    try {
      const res = await axios.get('http://127.0.0.1:8000/api/summary/');
      setSummary(res.data);
    } catch (error) {
      console.error('Error:', error);
      setSummary({ error: 'API connection failed' });
    }
  };

  const uploadFile = async () => {
    if (!file) return;
    
    const formData = new FormData();
    formData.append('csv_file', file);
    
    try {
      const res = await axios.post('http://127.0.0.1:8000/api/upload/', formData);
      setSummary(res.data);
    } catch (error) {
      console.error('Upload failed:', error);
    }
  };

  useEffect(() => {
    fetchSummary();
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h1>🧪 Chemical Equipment Visualizer</h1>
      
      <input type="file" accept=".csv" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={uploadFile} disabled={!file}>Upload CSV</button>
      
      <pre>{JSON.stringify(summary, null, 2)}</pre>
    </div>
  );
}

export default App;
