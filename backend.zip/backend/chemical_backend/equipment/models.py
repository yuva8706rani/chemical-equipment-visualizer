from django.db import models

class Meta:
    abstract = True
# இப்படி empty code இருக்கும்
