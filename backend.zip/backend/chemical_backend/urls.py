from django.urls import path
from equipment import views

urlpatterns = [
    path('api/upload/', views.upload_csv, name='upload_csv'),
    path('api/summary/', views.summary_view, name='summary'),
    path('api/pdf/', views.pdf_view, name='pdf_report'),
]
