from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view
from rest_framework.response import Response
import pandas as pd
import io
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Global variables
latest_data = None
latest_filename = None

def get_summary_data():
    global latest_data
    if latest_data is None or len(latest_data) == 0:
        return {
            "error": "No data uploaded yet",
            "total_count": 0,
            "avg_flowrate": 0,
            "avg_pressure": 0,
            "avg_temperature": 0,
            "type_distribution": {}
        }
    
    df = pd.DataFrame(latest_data)
    summary = {
        "total_count": len(df),
        "avg_flowrate": float(df['flowrate'].mean()),
        "avg_pressure": float(df['pressure'].mean()),
        "avg_temperature": float(df['temperature'].mean()),
        "type_distribution": df['equipment_type'].value_counts().to_dict()
    }
    return summary

def latest_csv_name():
    global latest_filename
    return latest_filename or "sample_data.csv"

@csrf_exempt
@api_view(['POST'])
def upload_csv(request):
    global latest_data, latest_filename
    
    if 'csv_file' not in request.FILES:
        return JsonResponse({"error": "No file provided"}, status=400)
    
    csv_file = request.FILES['csv_file']
    latest_filename = csv_file.name
    
    try:
        df = pd.read_csv(csv_file)
        latest_data = df.to_dict('records')
        summary = get_summary_data()
        return JsonResponse(summary, status=201)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=400)

@api_view(['GET'])
def summary_view(request):
    summary = get_summary_data()
    return JsonResponse(summary, safe=False)

@api_view(['GET'])
def pdf_view(request):
    summary_data = get_summary_data()
    
    # SAFE TEXT-ONLY PDF (No matplotlib crash!)
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    
    # Title
    p.setFont("Helvetica-Bold", 24)
    p.drawString(50, height - 80, "🧪 Chemical Equipment Analysis Report")
    p.setFont("Helvetica", 14)
    
    # Summary stats
    y = height - 150
    p.drawString(50, y, f"📁 File: {latest_csv_name()}")
    y -= 35
    p.drawString(50, y, f"🔢 Total Equipment: {summary_data['total_count']}")
    y -= 30
    p.drawString(50, y, f"💧 Avg Flowrate: {summary_data['avg_flowrate']:.1f}")
    y -= 25
    p.drawString(50, y, f"⚡ Avg Pressure: {summary_data['avg_pressure']:.2f}")
    y -= 25
    p.drawString(50, y, f"🌡️ Avg Temperature: {summary_data['avg_temperature']:.1f}")
    
    # Equipment distribution table
    y -= 40
    p.setFont("Helvetica-Bold", 14)
    p.drawString(50, y, "📊 Equipment Distribution:")
    p.setFont("Helvetica", 12)
    y -= 25
    
    for i, (equip_type, count) in enumerate(summary_data['type_distribution'].items()):
        p.drawString(70, y, f"{equip_type}: {count}")
        y -= 20
    
    p.save()
    buffer.seek(0)
    
    response = HttpResponse(buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="equipment_report.pdf"'
    return response
