from django.db import models

class Dataset(models.Model):
    file_name = models.CharField(max_length=255)
    upload_date = models.DateTimeField(auto_now_add=True)
    summary_data = models.JSONField()
    csv_data = models.TextField(blank=True)
    
    class Meta:
        ordering = ['-upload_date']

    def __str__(self):
        return self.file_name
