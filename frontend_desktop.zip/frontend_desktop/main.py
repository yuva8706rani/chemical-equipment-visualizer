import sys
import requests
import pandas as pd
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import os

class EquipmentVisualizer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.summary = None
        self.file_path = None
        self.initUI()
        self.test_backend()
    
    def initUI(self):
        self.setWindowTitle('🧪 Chemical Equipment Visualizer - DEBUG')
        self.setGeometry(100, 100, 1200, 800)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout()
        central_widget.setLayout(layout)
        
        # Status + Debug
        self.status_label = QLabel('🔄 Initializing...')
        self.status_label.setStyleSheet("font-size: 14px; padding: 10px;")
        layout.addWidget(self.status_label)
        
        # Buttons
        btn_layout = QHBoxLayout()
        self.test_btn = QPushButton('🧪 Test Backend')
        self.test_btn.clicked.connect(self.test_backend)
        self.file_btn = QPushButton('📁 Select CSV')
        self.file_btn.clicked.connect(self.select_file)
        self.upload_btn = QPushButton('🚀 Upload')
        self.upload_btn.clicked.connect(self.upload_file)
        self.upload_btn.setEnabled(False)
        self.pdf_btn = QPushButton('📄 PDF')
        self.pdf_btn.clicked.connect(self.download_pdf)
        self.pdf_btn.setEnabled(False)
        
        btn_layout.addWidget(self.test_btn)
        btn_layout.addWidget(self.file_btn)
        btn_layout.addWidget(self.upload_btn)
        btn_layout.addWidget(self.pdf_btn)
        layout.addLayout(btn_layout)
        
        # Debug text area
        self.debug_text = QTextEdit()
        self.debug_text.setMaximumHeight(100)
        self.debug_text.setPlaceholderText("Debug info will appear here...")
        layout.addWidget(QLabel("Debug Console:"))
        layout.addWidget(self.debug_text)
        
        # Summary
        self.summary_label = QLabel('No data')
        self.summary_label.setStyleSheet("font-size: 16px; padding: 20px; border: 1px solid #ddd; background: #f8f9fa;")
        layout.addWidget(self.summary_label)
        
        # Charts
        self.figure = Figure(figsize=(12, 6))
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)
    
    def log_debug(self, message):
        self.debug_text.append(f"[{QTime.currentTime().toString()}] {message}")
        print(message)
    
    def test_backend(self):
        self.log_debug("Testing backend connection...")
        try:
            response = requests.get('http://127.0.0.1:8000/api/summary/', timeout=5)
            self.log_debug(f"✅ Backend OK! Status: {response.status_code}")
            self.status_label.setText("✅ Backend Connected!")
            self.status_label.setStyleSheet("color: green; font-weight: bold;")
            
            if response.status_code == 200:
                self.summary = response.json()
                self.show_summary()
                self.plot_data()
                if 'error' not in self.summary:
                    self.pdf_btn.setEnabled(True)
            else:
                self.log_debug(f"Summary error: {response.text}")
        except Exception as e:
            self.log_debug(f"❌ Backend Error: {str(e)}")
            self.status_label.setText("❌ Backend OFF!")
            self.status_label.setStyleSheet("color: red; font-weight: bold;")
    
    def select_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select CSV", "", "CSV (*.csv)")
        if file_path:
            self.file_path = file_path
            self.upload_btn.setEnabled(True)
            self.log_debug(f"✅ CSV Selected: {os.path.basename(file_path)}")
    
    def upload_file(self):
        if not self.file_path:
            self.log_debug("❌ No CSV selected!")
            return
        
        self.log_debug("🚀 Starting upload...")
        try:
            with open(self.file_path, 'rb') as f:
                files = {'csv_file': (os.path.basename(self.file_path), f, 'text/csv')}
                self.log_debug("Sending POST request...")
                response = requests.post('http://127.0.0.1:8000/api/upload/', 
                                       files=files, timeout=10)
            
            self.log_debug(f"Upload response: {response.status_code}")
            self.log_debug(f"Response text: {response.text}")
            
            if response.status_code == 201:
                self.summary = response.json()
                self.log_debug("✅ UPLOAD SUCCESS! Data loaded!")
                self.show_summary()
                self.plot_data()
                self.pdf_btn.setEnabled(True)
                self.status_label.setText("✅ Upload Success!")
            else:
                self.log_debug(f"❌ Upload FAILED! Status: {response.status_code}")
        except Exception as e:
            self.log_debug(f"❌ Upload Exception: {str(e)}")
    
    def show_summary(self):
        if self.summary:
            if 'error' in self.summary:
                self.summary_label.setText(f"⚠️ {self.summary['error']}")
            else:
                text = f"""
Total: {self.summary.get('total_count', 0)} equipment
Flowrate: {self.summary.get('avg_flowrate', 0):.1f}
Pressure: {self.summary.get('avg_pressure', 0):.2f}
Temperature: {self.summary.get('avg_temperature', 0):.1f}

Types: {dict(self.summary.get('type_distribution', {}))}
                """
                self.summary_label.setText(text.strip())
    
    def plot_data(self):
        self.figure.clear()
        if self.summary and 'type_distribution' in self.summary and self.summary['type_distribution']:
            types = list(self.summary['type_distribution'].keys())
            counts = list(self.summary['type_distribution'].values())
            
            self.log_debug(f"Plotting: {types} = {counts}")
            
            ax1 = self.figure.add_subplot(121)
            colors = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF']
            ax1.bar(types, counts, color=colors[:len(types)])
            ax1.set_title('Equipment Distribution')
            ax1.tick_params(axis='x', rotation=45)
            
            ax2 = self.figure.add_subplot(122)
            ax2.pie(counts, labels=types, autopct='%1.1f%%', colors=colors[:len(types)])
            ax2.set_title('Type Distribution')
        else:
            ax = self.figure.add_subplot(111)
            ax.text(0.5, 0.5, 'No Data to Plot\nUpload CSV first!', ha='center', va='center', fontsize=16)
            ax.set_title('Upload Data First')
        
        self.figure.tight_layout()
        self.canvas.draw()
    
    def download_pdf(self):
        try:
            self.log_debug("📄 Downloading PDF...")
            response = requests.get('http://127.0.0.1:8000/api/pdf/', timeout=10)
            if response.status_code == 200:
                pdf_path = 'equipment_report.pdf'
                with open(pdf_path, 'wb') as f:
                    f.write(response.content)
                self.log_debug(f"✅ PDF saved: {pdf_path}")
                os.startfile(os.path.dirname(pdf_path))
            else:
                self.log_debug(f"❌ PDF failed: {response.status_code}")
        except Exception as e:
            self.log_debug(f"❌ PDF Error: {str(e)}")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = EquipmentVisualizer()
    ex.show()
    sys.exit(app.exec_())
